from flask import Flask, render_template
from flask_bootstrap import Bootstrap


#img_folder='static/img'
app = Flask(__name__, template_folder='templates')
bootstrap = Bootstrap(app)

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/index')
def index1():
    return render_template('index2.html')


@app.route('/promotion')
def promotion():
    return render_template('promotion.html')


@app.route('/image_mars')
def image_mars():
    return render_template('image_mars.html')


@app.route('/carousel')
def carousel():
    return render_template('carousel.html')
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8080)
